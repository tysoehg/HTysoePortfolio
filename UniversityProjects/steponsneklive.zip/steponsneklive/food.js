class Food 
{
	constructor (x,y)
	{
		var fud = this;
		fud.x = x;
		fud.y = y;
		fud.draw = function() 
		{
			ctx.fillStyle="#d34a3a";
			ctx.fillRect(x,y,bs,bs);
			ctx.fillStyle="#000000";
		}
	}
}
	