class food 
{
	constructor (x,y)
	{
		this.x = x;
		this.y = y;
		this.fs = bs;
		this.eaten = false;
		var coin = new Image();
		var fram = 0;
		coin.src = "coin.png";
	//	var canvas = document.getElementById("myCanvas");
	//	var ctx = canvas.getContext("2d");
		this.draw = function() 
		{
			ctx.fillStyle="#d34a3a";
			ctx.fillRect(x,y,this.fs,this.fs);
			ctx.fillStyle="#000000";
		}
		
		
	}
	
}