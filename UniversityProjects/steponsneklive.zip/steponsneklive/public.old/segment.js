class segment
{
	constructor(x,y)
	{
		this.x = x;
		this.y = y;
	}
}