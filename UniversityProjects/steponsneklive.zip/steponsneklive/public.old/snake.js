class snake 
{
	constructor(x,y,col,cleft,cup,cright,cdown) 
	{
		var segments = []; // holds all segment objects
		var that = this;
		this.col = col; // snake colour
		this.x = x;
		this.y = y;
		that.xc = []; // array containing x coordinate of each segment
		that.yc = []; // array containing y coordinate of each segment
		that.score = 0;
		that.alive = true;
		var deadsegx = 0; // contains x coordinate of last killed tail segment
		var deadsegy = 0; // contains y coordinate of last killed tail segment
		// for custom controls / local 2 player
		var cup = cup; // contains keycode of up control
		var cleft = cleft; // contains keycode of left control
		var cright = cright; // contains keycode of right control
		var cdown = cdown; // contains keycode of down control
		var cntrl = "right"; // contains most recent control input
		
		// create initial segments + populate segments array
		for (var i = 0; i < 4; i++)
		{
			var xs = x-(i*bs);
			segments.push(new segment(xs,y));
		}
		this.seglen = segments.length; // contains length of snake
		
		// event listener for key input
		document.addEventListener("keydown", function(e)
		{
			if (e.keyCode == cleft && cntrl != "right") // left
			{
				cntrl = "left";
			}
			if (e.keyCode == cup && cntrl != "down") // up
			{
				cntrl = "up";
			}
			if (e.keyCode == cright && cntrl != "left") // right
			{
				cntrl = "right";
			}
			if (e.keyCode == cdown && cntrl != "up") // down
			{
				cntrl = "down";
			}
			if (e.keyCode == 80) // keycode 80 = 'p' as in 'pause'
			{
				console.log("pausing");
				playing = false;
			}
			
		});
		
		var drawSnake = function()
		{
			var len = segments.length-1;
			
			for (var i=0;i< len; i++) // for each segment
			{
				// draw segment
				ctx.fillStyle = col; // set colour
				ctx.fillRect(segments[i].x, segments[i].y ,bs,bs);
			}
		}
		
		var move = function()
		{
			var len = segments.length-1;
			// save tail segment position 
			deadsegx = segments[len].x;
			deadsegy = segments[len].y;
			// clear tail segment drawing
			ctx.clearRect(deadsegx,deadsegy,bs,bs);
			// remove tail segment object from segments array
			segments.pop(segments[len]);
			// get direction
			control();
			// add new segment
			segments.unshift(new segment(x,y));
			// check collision
			collide();
			// redraw snake
			drawSnake();
		}
		
		var collide = function()
		{
			// WALL COLLISION
			if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height)
			{
				console.log("WALLED");
				that.alive = false;
			}
			
			// SELF COLLISION
			for (var i = 1; i < segments.length; i++) // for every segment
			{
				if (x == segments[i].x && y == segments[i].y) // if same space as segment
				{
					console.log("EATING SELF")
					that.alive = false;
				}
			}
		}
		var reqFood = function()
		{
			console.log("reqing food");	
			socket.broadcast.emit("request food1", snake1.score);
			if (playerid == 1)
			{
			}
			if (playerid == 2)
			{
				socket.broadcast.emit("request food2", snake2.score);
			}
			socket.emit("reqfood", "s");
		}
		
		var eat = function()
		{
			for (var n = 0; n < foods.length; n++)
			{
				if (x == foods[n].x && y == foods[n].y)
				{
					that.score++;
					console.log("yum");
					foods.splice(n);
					segments.push(new segment(deadsegx,deadsegy));
					that.seglen = segments.length;
					that.reqFood();
				}
			}
		}
		
		var coord = function() // updates arrays of segment coordinates
		{
			// clear arrays
			that.xc = [];
			that.yc = [];
			// repopulate arrays
			for (var i = 0; i < segments.length; i++)
			{
				var xx = segments[i].x;
				var yy = segments[i].y;
				that.xc.push(xx);
				that.yc.push(yy);
				
			}
		}
		
		var control = function()
		{
			if (cntrl == "left" )
			{
				if (x-bs != segments[0].x)
				{
					x = x-bs;
				}
			} 
			if (cntrl == "up")
			{
				if (y-bs != segments[0].y)
				{
					y = y-bs;
				}
			}
			if (cntrl == "right")
			{
				if (x+bs != segments[0].x)
				{
					x = x+bs;
				}
			}
			if (cntrl == "down")
			{
				if (y+bs != segments[0].y)
				{
					y = y+bs;
				}
			}
		}
		
		that.goup = function() 
		{
			cntrl = "up";
		}
		that.goleft = function()
		{
			cntrl = "left";
		}
		that.goright = function()
		{
			cntrl = "right";
		}
		that.godown = function()
		{
			cntrl = "down";
		}
		
		
		that.update = function() 
		{
			move();
			eat();
			coord();
			this.seglen = segments.length;
		}
		
		drawSnake();
		
		
			
	}
}

