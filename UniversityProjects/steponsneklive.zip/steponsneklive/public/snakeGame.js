var bs = 100;
		
function drawCanvas()
{
	this.canvas = document.getElementById("myCanvas");
	this.ctx = canvas.getContext("2d");
	this.foods = [];
	this.snakes = [];
	this.playing = true;
	this.surplus = 1;
	snakes.push(snake1 = new snake(500,200,"#000000",37,38,39,40));
	foods.push(new food(bs,bs*3));
	foods.push(new food(bs*2,bs*6));
	snakes.push(snake2 = new snake(400,400,"#ffffff",65,87,68,83));
	
	setInterval( function()
		{
			if (playing)
			{
				if (snake1.alive != false)
				{
					snake1.update();
				}
				else if (snake1.alive == false) 
				{
					
				}
				if (snakes.length > 1)
				{
					if (snake2.alive != false)
					{
						twoplayer = true;
						snake2.update();
					}
				}
				if (twoplayer = true)
				{
					document.getElementById("p2").innerHTML = "T W O";
					overlap();
				}
				if (twoplayer != true)
				{
					document.getElementById("double").style.display = "none";
				}
				
				for (var i = 0; i < foods.length; i++)
				{
					foods[i].draw();
				}
				
				document.getElementById("score1").innerHTML = snake1.score;
				document.getElementById("score2").innerHTML = snake2.score;
				
				if (snake1.alive == false && snake2.alive == false)
				{
					playing = false;
				}
				
			}
			else if (!playing)
			{
				ctx.clearRect(0,0,canvas.width,canvas.height);
				ctx.font = "500px Tahoma";
				ctx.fillText("G  A  M  E . O  V  E  R",100,400,1800);
			
				if (snake1.score > snake2.score)
				{
					ctx.fillText("P L A Y E R . 1 . W I N S", 500,900,1000);
				}
				else if (snake1.score < snake2.score)
				{
					ctx.fillText("P L A Y E R . 2 . W I N S", 500,900,1000);	
				}
				else if (snake1.score == snake2.score)
				{
					ctx.fillText("D R A W", 750,900,500);
				}
			}
		} , 250);
	
	this.overlap = function()
	{
		var i;
		var j;
		for (i = 0; i < snakes[0].seglen; i++)
		{
			for (j = 0; i < snakes[1].seglen; i++)
			{
				if (snake1.xc[i] == snake2.xc[j] && snake1.yc[i] == snake2.yc[j])
				{
					console.log("C A N N I B A L C A N N I B A L");
					console.log("O N E : " + i);
					console.log("T W O : " + j);
					playing = false;
				}
				if (snake2.xc[i] == snake1.xc[j] && snake2.yc[i] == snake1.yc[j])
				{
					
					console.log("C A N N I B A L C A N N I B A L");
					console.log("O N E : " + i);
					console.log("T W O : " + j);
					playing = false;
				}
			}
		}
	}
	
	this.checkrand = function(x,y) // checks the proposed position of new food is not taken by tail
		{
			var newspace = false;
			while (newspace == false)
			{
				for (var j = 0; i < snakes.lenght; i++) // for each snake
				{
					for (var i = 0; i < snakes[j].seglen; i++) // check each segment
					{
						if (x == segments[i].x && y == segments[i].y) // if square IS already taken
						{
							// reshuffle randoms
							x = Math.floor((Math.random() * ((canvas.width / bs)-1) + 0));
							y = Math.floor((Math.random() * ((canvas.height / bs)-1) + 0));
						}
						else // if square is not taken 
						{
							newspace = true; 
							break;
						}
					}
				}
			}	
		}
		
		
		
		
			
}
window.addEventListener("load", drawCanvas);