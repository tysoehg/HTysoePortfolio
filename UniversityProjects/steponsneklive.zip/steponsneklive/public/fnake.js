class fnake
{
    constructor()
    {
        this.xc = [];
        this.yc = [];
        this.drawFnake = function()
        {
            var drawFnake = function()
		{
			var len = xc.length-1;
			
			for (var i=0;i < len; i++) // for each segment
			{
				// draw segment
				ctx.fillStyle = col;
				ctx.fillRect(xc[i], yc[i] ,bs,bs);
			}
		}
        }
    }
}