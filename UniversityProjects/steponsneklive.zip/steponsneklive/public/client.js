function thegame()
{// top level client function
	// it == this used to define public variables/functions
    var it = this;
    this.score = null;
	var name = null;
	var email = null;
	var highscore = null;
	var played = null;
	
	// connect to server
	// save connection as socket 
    it.socket = io.connect("http://localhost:8081");
    
	it.bs = 50;
    it.canvas = document.getElementById("myCanvas");
    it.ctx = canvas.getContext("2d");
    it.snakes = [];
    it.foods = [];
    it.playing = false;
    it.playerid;
    it.decor = new Image();
	
	console.log(this.email);
	
	if (getCook("email"))
	{
		console.log("IN THE OVEN");
		var loginfo = {email: getCook("email"), pass: getCook("pass")};
		socket.emit("login", loginfo);
	}
	else
	{
		console.log("or not");
	}
	
    // BUTTONS
    // prep functions
    it.pret1 = function()
    {
        if (it.playerid != 2)
        {
            it.playerid = 1;
        }
        socket.emit("ready1");
    }
    it.pret2 = function()
    {
        if (it.playerid != 1)
        {
            it.playerid = 2;
        }
        socket.emit("ready2");
    }
    
    // sends player's snake object to server
    it.sendsnake = function()
    {
        socket.emit("send snake", snake);
    }
    // sends message to server to update score
    it.sendscore = function()
    {
        if (playerid == 1)
        {
            socket.emit("score1");
        }
        if (playerid == 2)
        {
            socket.emit("score2");
        }
    }
    
    // button to start game
    it.go = function()
    {
        // sends go message to server
        socket.emit("go");
    }
    
    it.newfood = function()
    {
        // randomise grid position
        var fx = Math.floor((Math.random() * (canvas.width / bs) + 0));	
        var fy = Math.floor((Math.random() * (canvas.height / bs) + 0));
        // create food with random grid variables
        foods.push(food = new Food(fx*bs,fy*bs));
        socket.emit("new food", food);
    }
    
    // checks for snake on snake collision
    it.cannibal = function()
    {
        // update both snakes coordinate arrays
        snake.coord();
        snake2.coord();
        // if this snake's head's x value is in array of snake2's x coordinates
        if (snake2.xc.indexOf(snake.xc[0]) > -1)
        {
            // if this snake's head's y value is in array of snake2's y coordinates
            if (snake2.yc.indexOf(snake.yc[0]) > -1)
            {
                // stop this snake
                it.playing = false;
            }
        }
    }
	
   
    // G A M E   S E T   U P
	
	// on successful log in
	socket.on("loggedin", function(data)
	{
		name = data[0].name;
		document.getElementById("logged").innerHTML = name;
		email = data[0].email;
		pass = data[0].pass;
		highscore = data[0].highscore;
		document.getElementById("highscore").innerHTML = highscore;
		played = data[0].gamesplayed;
		document.getElementById("gamesplayed").innerHTML = played;
		document.cookie = "pass=" + pass + ";";
		document.cookie = "email=" + email + ";";
		console.log(document.cookie);
	});
		
	
    // on server response to ready 1 and 2
    socket.on("greenlight1", function()
    {
        // player 1 creates snake
        if (it.playerid == 1)
        {
            snake = new Snake(300,200,"#000000","#d34a3a");
            snakes.push(snake);
            snakes[0].head.src = "/segw.jpg";
            snakes[0].body.src = "/segb.jpg";
        }
        // button turns green to signify readiness
        $("#pret1").css("background-color", "#05dc00");
    });
    socket.on("greenlight2", function()
    {
        // player 2 creates snake
        if (it.playerid == 2)
        {
            snake = new Snake(300,400,"#ffffff","#d34a3a");
            snakes.push(snake);
        }
        // button turns green to signify readiness
        $("#pret2").css("background-color", "#05dc00");
        // both players send snakes to each other
        it.sendsnake();
    });
    // on recieving other player's snake object
    socket.on("other snake", function(data)
    {
        // create snake2 from other player's snake object
        snakes.push(snake2 = new Snake(data.x,data.y,data.col));
    });
    
    // G A M E   S T A R T
    // on server response to big green "go" button
    socket.on("play", function()
    {
        snakes[0].head.src = "/segr.jpg";
        snakes[0].body.src = "/segb.jpg";
        if (snakes.length > 1)
        {
            snakes[1].head.src = "/segb.jpg";
            snakes[1].body.src = "/segw.jpg";
        }
        // start this snake
        it.playing = true;
		if (email != null)
		{
			socket.emit("newgame", email);
		}
    });
	
	// on gamesplayed return from server
	socket.on("played", function(data)
	{
		document.getElementById("gamesplayed").innerHTML = data;
	});
    
    // G A M E   U P D A T E S
    // on recieving other snakes position update
    socket.on("other segments", function(data)
    {
        // calls method to update snake2's segment array
        snakes[1].updateSegments(data);
        // calls method to check for snake on snake collision
        it.cannibal();
    });
    // on recieving other player's food update
    // other player eats, creates new food, sends food to this client
    socket.on("food update", function(data)
    {
        // reset foods array 
        it.foods = [];
        // create new food from data from other player
        it.foods.push(food = new Food(data.x,data.y));
        // draw new food object
        it.foods[0].draw();
    });
    
    // M O N I T O R   S C O R E S
    // on recieving score update from server
    socket.on("retscore1", function(data)
    {
        // update score board
		console.log("score " + data);
		this.score = data;
        $("#score1").html(data);
    });
    
    socket.on("retscore2", function(data)
    {
        // update score board
        $("#score2").html(data);
    });
        
    // G A M E   F U N C T I O N
    it.play = function()
    {
        setTimeout(function() 
        {
            requestAnimationFrame(it.play);
            // if this snake is playing / alive
            if (playing == true)
            {
                // draw foods
                it.foods[0].draw();
                // update this snake
                snakes[0].update();
                // draw other 'ghost' snake
                if (snakes.length > 1)
                {
                    snakes[1].drawSnake();
                }
            }
        }, 250);
    }
    
    // create initial food object
    foods.push(new Food(600,300));
    it.play();
    
}
window.addEventListener("load", thegame);