class Snake 
{
	constructor(x,y,col,col2) 
	{
            var that = this;
            // array of segment objects
            var segments = [];
            // body colour
            this.col = col;
            // head colour
            this.col2 = col2;
            // head segment coordinates
            this.x = x;
            this.y = y;
            // array of each segment's x coordinate
            that.xc = [];
            // array of each segment's y coordinate
            that.yc = [];
            // snakes score
            that.score = 0;
            // coordinates of most recently removed tail segment
            var deadsegx = 0;
            var deadsegy = 0;
            // control keycodes
            var cup = 38;
            var cleft = 37;
            var cright = 39;
            var cdown = 40;
            // control variable, set to initial direction of right
            var cntrl = "right";
            that.head = new Image();
            that.body = new Image();
            
            
            
            // create snake's initial segments
            for (var i = 0; i < 4; i++)
            {
                    var xs = x-(i*bs);
                    segments.push(new segment(xs,y));
            }
            
            // key event listener
            document.addEventListener("keydown", function(e)
            {
                if (e.keyCode == cleft && cntrl != "right") // left
                {
                    cntrl = "left";
                }
                if (e.keyCode == cup && cntrl != "down") // up
                {
                    cntrl = "up";
                }
                if (e.keyCode == cright && cntrl != "left") // right
                {
                    cntrl = "right";
                }
                if (e.keyCode == cdown && cntrl != "up") // down
                {
                    cntrl = "down";
                }
                if (e.keyCode == 80) // keycode for 'p'
                {
                    playing = false;
                }   
            });
            
            // method to draw snake
            that.drawSnake = function()
            {
                var len = segments.length-1;
                
                for (var i=0;i< len; i++) // for each segment
                {
                    // draw segment
                    ctx.fillStyle = col;
                    if (i == 0) // if drawing head segment
                    {
                        ctx.drawImage(that.head,segments[i].x,segments[i].y);
                    }
                    else if (i != 0)
                    {
                        ctx.drawImage(that.body,segments[i].x,segments[i].y);
                    }
                }
            }
            // method to define random colour
            function getRandomColor() 
            {
                var letters = '456789ABCDEF';
                var color = '#';
                for (var i = 0; i < 6; i++ ) 
                {
                    color += letters[Math.floor(Math.random() * 12)];
                }
                return color;
            }
            
            // method to update snakes position
            var move = function()
            {
                var len = segments.length-1;
                // save tail segment position 
                deadsegx = segments[len].x;
                deadsegy = segments[len].y;
                // clear tail segment drawing
                ctx.clearRect(deadsegx,deadsegy,bs,bs);
                // remove tail segment object
                segments.pop(segments[len]);
                // get direction
                control();
                // add new segment
                segments.unshift(new segment(x,y));
                // check collision
                collide();
                // redraw snake
                that.drawSnake();
                // send position update to server
                // consists of array of all segments
                socket.emit("position update", segments);
            }
            
            // checks for wall and self collisions
            var collide = function()
            {
                    // WALL COLLISION
                    if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height)
                    {
                            console.log("WALLED");
                            // stops this snake
                            playing = false;
                    }
                    
                    // SELF COLLISION
                    for (var i = 1; i < segments.length; i++) // for every segment
                    {
                            if (x == segments[i].x && y == segments[i].y) // if same space as segment
                            {
                                    console.log("EATING SELF")
                                    // stops this snake
                                    playing = false;
                            }
                    }
            }
            
            // method to check for snake eating
            var eat = function()
            {
                for (var n = 0; n < foods.length; n++) // for each food object in foods
                {
                    if (x == foods[n].x && y == foods[n].y) // if snakes head coordinates are same as food coordinates
                    {
                        // increment score
                        that.score++;
                        // remove food object
                        foods.splice(n);
                        // revive last removed tail segment
                        segments.push(new segment(deadsegx,deadsegy));
                        // send score update to server
                        sendscore();
                        // creates new food object
                        newfood();
                        // set new random head colour
                    //    col2 = getRandomColor();
                    }
                }
            }
            
            that.coord = function() // updates arrays of segment coordinates
            {
                // clear arrays of x and y coordinates
                that.xc = [];
                that.yc = [];
                for (var i = 0; i < segments.length; i++) // for each segment in segments
                {
                    // put segments x and y coordinates in respective arrays
                    var xx = segments[i].x;
                    var yy = segments[i].y;
                    that.xc.push(xx);
                    that.yc.push(yy);
                }
            }
            
            // update snakes head coordinates by cntrl variable
            var control = function()
            {
                    if (cntrl == "left")
                    {
                            if (x-bs != segments[0].x) 
                            {
                                    x = x-bs;
                            }
                    } 
                    if (cntrl == "up")
                    {
                            if (y-bs != segments[0].y)
                            {
                                    y = y-bs;
                            }
                    }
                    if (cntrl == "right")
                    {
                            if (x+bs != segments[0].x)
                            {
                                    x = x+bs;
                            }
                    }
                    if (cntrl == "down")
                    {
                            if (y+bs != segments[0].y)
                            {
                                    y = y+bs;
                            }
                    }
            }
            
            // on screen buttons for mouse and touchscreen interface
            that.goup = function()
            {
                    cntrl = "up";
            }
            that.goleft = function()
            {
                    cntrl = "left";
            }
            that.goright = function()
            {
                    cntrl = "right";
            }
            that.godown = function()
            {
                    cntrl = "down";
            }
            
            // method to update ghost snake
            that.updateSegments = function(newSegments)
            {
                var len = segments.length-1;
                // save tail segment position 
                deadsegx = segments[len].x;
                deadsegy = segments[len].y;
                // clear tail segment drawing
                ctx.clearRect(deadsegx,deadsegy,bs,bs);
                // update segments array with new data from server
                segments = newSegments;
                // draw snake
                that.drawSnake();
            }
                            
            // method to update player's snake            
            that.update = function() 
            {
                // updates position
                move();
                // checks for eating
                eat();
                // updates coordinate arrays
                that.coord();
            }
            
            // initial drawSnake
            that.drawSnake();
            
            
                    
	}
}
