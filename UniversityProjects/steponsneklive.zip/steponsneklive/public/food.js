class Food 
{
	constructor (x,y)
	{
		var fud = this;
		// food coordinates
		fud.x = x;
		fud.y = y;

	// animation/sprite sheet code
		// link image of static as sprite sheet
		fud.noise = new Image();
		fud.noise.src = "/static.jpg";
		// animation variables
		var numberOfFrames = 10;
		var frameIndex = 0;
		var tickCount = 0;
		var ticksPerFrame = 0;
		
		// method to draw food
		fud.draw = function()
		{
			// draw static image
			ctx.drawImage(fud.noise // the image
			,frameIndex * bs // x position of segment of original image
			,0 // y position of segment of original image
			,bs // x size of segment of original image
			,bs	// y size of segment of original image
			,fud.x // x position on canvas
			,fud.y // y position on canvas
			,bs	// x size on canvas
			,bs // y size on canvas
			);
			// animate static image
			fud.animate();
		}
		// method to animate static image
		fud.animate = function()
		{
			// increment frame index
			frameIndex++;
			// if frame index has reached final frame
			if (frameIndex == numberOfFrames)
			{
				// reset frame index
				frameIndex = 0;
			} 
		};
	}
}
	