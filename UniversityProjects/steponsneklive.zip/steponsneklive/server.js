// dependencies
var express = require("express");
var app = express();
var server = require("http").Server(app);
var io = require("socket.io")(server);
var mysql = require("mysql");

// conn = mysql connection object
// conn.query() to use
var conn = mysql.createConnection({
    host: "localhost",
    port: 3306,
    user: "snek",
    password: "password",
    database: "snake"
});

// player scores
var score1 = 0;
var score2 = 0;

// tell express where client code is/ where to server
app.use(express.static("public"));

// called when client connects  
io.on("connection", function (socket) 
{
    console.log("Somebody's doing the connecting");
    
    // method to return scores to players
    var retscores = function()
    {
        // sends score details to all connected
        io.emit("retscore1", score1);
        io.emit("retscore2", score2);
    }
	
	var saveScore = function(pscore)
	{
		console.log(pscore);
		conn.query("SELECT highscore FROM users WHERE email = '" + pscore.email + "';", function(error,results,fields)
		{
			if (error)
			{
				console.log(error);
			}
			if (results)
			{
				if (results[0].highscore == null || results[0].highscore < pscore.score)
				{
					conn.query("UPDATE users SET highscore = " + pscore.score + " WHERE email = '" + pscore.email + "';");
				}
			}
		});
	}
    
    
    conn.query("SELECT * FROM users", function(error,results,fields)
    {
        if (error) 
        {
            console.log(error);
        }
		if (results != null)
		{
			for (i=0; i < results.length; i++)
			{
				console.log(results[i].email);
			}
		}
    });
    
    
	
	// on login attempt
	socket.on("login", function(data)
	{
		console.log(data.email);
		
		conn.query("SELECT * FROM users WHERE email = '" + data.email + "';", function(error,results,fields)
		{
			if (error)
			{
				console.log(error);
			}
			if (results)
			{
				if (results[0].pass == data.pass)
				{
					// successful login
					console.log(results[0].email + " is logging in");
					socket.emit("loggedin", results);
				}
			}
		});
	});
		
    // on ready1 button
    socket.on("ready1", function()
    {
        // reset player1's score
        score1 = 0;
        // send greenlight message for player 1 to clients
        io.emit("greenlight1");
    });
    // on ready2 button
    socket.on("ready2", function()
    {
        // reset player2's score
        score2 = 0;
        // send greenlight message for player 1 to clients
        io.emit("greenlight2");
    });
    // on start game button
    socket.on("go", function()
    {
        // send message to start game
        io.emit("play");
        // return scores
        retscores();
    });
	// on logged in player starting new game
	socket.on("newgame", function(data)
	{
		conn.query("SELECT gamesplayed FROM users WHERE email = '" + data + "';", function(error,results,fields)
		{
			if (error)
			{
				console.log(error);
			}
			if (results)
			{
				var played = 1;
				if (results[0].gamesplayed != null)
				{
					played = results[0].gamesplayed + 1;
					console.log(played);
				}
				console.log(data);
				conn.query("UPDATE users SET gamesplayed = " + played + " WHERE email = '" + data + "';");
				socket.emit("played", played);
			}
		});
	});
	
    // on message with snake
    socket.on("send snake", function(data)
    {
        // relay snake to other clients
        socket.broadcast.emit("other snake", data);
    });
    // on message with position update
    socket.on("position update", function(data)
    {
        // relay segments to other clients
        socket.broadcast.emit("other segments", data);
    });
    // on message with new food update
    socket.on("new food", function(data)
    {
        // relay food to other clients
        socket.broadcast.emit("food update", data);
    });
    // when a snake scores/eats
    socket.on("score1", function()
    {
        // increase player1's score
        score1++; 
        // return scores
        retscores();
    });
    socket.on("score2", function()
    {
        // increase player2's score
        score2++;
        // return scores
        retscores();
    });
    // on request to save scores
    socket.on("savescore", function(data)
    {
        saveScore(data);
    });
    
});

// listen on port 8081
server.listen(8081, function () 
{
    console.log("Server started.");
});
