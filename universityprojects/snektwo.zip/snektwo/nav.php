<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<meta name=viewport content="width=device-width, initial-scale=1.0">
<title>snek</title>
<link rel='StyleSheet' href='style.css' type='text/css'>
</head>
<body>
<nav>
<ul>
<a href="profile.php"><li>Profile</li></a>
<a href="soapbox.php"><li>Soapbox</li></a>
<a href="http://localhost:8081/game.html"><li>Game</li></a>
<a href="allusers.php"><li>Users</li></a>
<a href="index.php"><li>Login</li></a>
<?php
// if logged in
if (isset($_SESSION))
{	
// if loggged into admin account
if ($_SESSION['admin'] == true)
{
	// add gamestats link after nav bar
	// styled to span screen
	echo "<a href='stats.php'><li style='width:100%;background-color:black;color:white;opacity:0.33;font-size:1.5em;'>G A M E S T A T S</li></a>";
}
}
?>
</ul>
</nav>