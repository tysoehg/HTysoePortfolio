<?php
include("consql.php");
// mysql query to increment number of likes on soap identified by soap_id (here 'sid') from post form
mysqli_query($conn, "UPDATE soap SET likes = likes + 1 WHERE soap_id = ".$_POST['sid'].";");
// redirect back to the soapbox
header("location: soapbox.php");
exit;