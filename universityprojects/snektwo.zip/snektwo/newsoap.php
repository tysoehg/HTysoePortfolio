<?php
session_start();
include("consql.php");
// fetch soap details from post form
$title = $_POST['soaptitle'];
$text = $_POST['soaptext'];
// get user details from session variables
$name = $_SESSION['name'];
$id = $_SESSION['user_id'];
// query to create new soap from session variables and post values
$query = "insert into soap (title, author, author_id, soaptext) values ('".$title."','".$name."','".$id."','".$text."');";
// execute query
if(mysqli_query($conn, $query))
{
	echo "success";
}
else 
{
	echo mysqli_error($conn);
}
mysqli_close($conn);
// redirect back to the soapbox
header("location: soapbox.php");
exit;
?>