<?php
include("consql.php");
// fetch values from post form
$email = $_POST['emaillogin'];
$pass = $_POST['passlogin'];
// query to fetch login details identified by email 
$query = "select email, pass, user_id, name, admin from users where email='".$email."';";
// execute query
$results = mysqli_query($conn, $query);
// if more than 0 rows returned
if (mysqli_num_rows($results) > 0)
{
	// fetch associative array of values from mysql
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC);
	// if supplied password matches password stored in the database
	if ($row['pass'] == $pass)
	{
		// start a new session
		session_start();
		// set session variables user_id and name
		$_SESSION['user_id'] = $row['user_id'];
		$_SESSION['name'] = $row['name'];
		// if logging into an admin account
		if ($row['admin'] == true)
		{
			// set admin session variable with value 'true'
			$_SESSION['admin'] = true;
		}
		else
		{
			// set admin session variable with value 'false'
			// in case an admin had been previously logged in to the same client 
			$_SESSION['admin'] = false;
		}
		// redirect to players profile page
		header("location: profile.php");
		exit;
	}
}

	
?>