<?php
session_start();
include("nav.php");
include("consql.php");
?>
<header>
<h2 id="title">S T A T S</h2>
</header>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
// Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() 
	  {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Name');
        data.addColumn('number', 'Highscore');
        data.addRows([
		<?php
		// fetch relevant user details
		$query = "SELECT name, highscore FROM users ORDER BY highscore DESC;";
		// define graph name and notify button title
		$title1 = "Highscore of each player";
		$notify1 = "Notify top player";
		// if filtered by gender - from post form select box -
		if ($_POST)
		{
			// if filtered to male only
			if ($_POST['gender'] == "male")
			{
				$query = "SELECT name, highscore FROM users WHERE gender = 'M' ORDER BY highscore DESC;";
				$title1 = "Highscore of each male player";
				$notify1 = "Notify top male player";
			}
			// if filtered to female only
			if ($_POST['gender'] == "female")
			{
				$query = "SELECT name, highscore FROM users WHERE gender = 'F' ORDER BY highscore DESC;";
				$title1 = "Highscore of each female player";
				$notify1 = "Notify top female player";
			}
		}
		// execute query
		$results = mysqli_query($conn, $query);
		if (mysqli_num_rows($results) > 0)
		{
			while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
			{
				echo "['".$row['name']."',".$row['highscore']."],";
			}
		}
		echo	"]);
        // Set chart options
        var options = {'title':'".$title1."',
                       'width':800,
                       'height':400};";	
		?>

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
	  
	        // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart2);
	  
	  // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart2() 
	  {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Age');
        data.addColumn('number', 'Games Played');
        data.addRows([
		<?php
		$results = mysqli_query($conn, "SELECT age, gamesplayed FROM users ORDER BY age ASC;");
		if (mysqli_num_rows($results) > 0)
		{
			while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
			{
				echo "['".$row['age']."',".$row['gamesplayed']."],";
			}
		}
		?>
        ]);

        // Set chart options
        var options = {'title':'Games played by age',
                       'width':800,
                       'height':400};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('chart_div2'));
        chart.draw(data, options);
      }
</script>
<article>
<section>
<div>
<form method="POST" action="stats.php">
Gender	
<select name="gender" id="genders">
<option value="both">Both</option>
<option value="male">Male</option>
<option value="female">Female</option>
</select>
<input type="submit">
</form>
<?php
if ($_POST)
{
	echo "<form method='POST' action='notify.php'><input type='hidden' name='gender' value='".$_POST['gender']."'><input type='submit' value='".$notify1."'>";
}
// close mysql connection
mysqli_close($conn);
?>
<div id="chart_div"></div>
</div>
<div id="chart_div2"></div>

	
</section>
</article>
