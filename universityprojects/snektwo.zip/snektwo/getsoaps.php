<?php

// D E P R E C A T E D
// E                 E
// P                 P
// R                 R
// E                 E
// C                 C
// A                 A
// T                 T
// E                 E
// D E P R E C A T E D

$query = "SELECT * FROM soap WHERE author_id = '".$_SESSION['user_id']."';";
$results = mysqli_query($conn, $query);
if (mysqli_num_rows($results) > 0)
{
	while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
	{
		echo "<div class='soap'><h3>".$row['title']."</h3><h4>".$row['author']."</h4>
		<p>".$row['soaptext']."</p>".$row['soap_id']."</div>";
	}
}
?>