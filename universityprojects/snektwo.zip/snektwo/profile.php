<?php
session_start();
include("nav.php");
include("consql.php");
// fetch logged in user_id from session variable
$id = $_SESSION['user_id'];
// if get id variable set, intention is to view a different user's profile
// use id supplied through get variable to populate the rest of the page
if ($_GET) { $id = $_GET['id']; }
// select all information on specified user
$results = mysqli_query($conn, "select * from users where user_id='".$id."';");
if (mysqli_num_rows($results) > 0)
{
	// fetch user detail variables from mysql query results
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC);
	$name = $row['name'];
	$email = $row['email'];
	$age = $row['age'];
	$city = $row['city'];
	$gender = $row['gender'];
	$bio = $row['bio'];
	$special = $row['special'];
	$highscore = $row['highscore'];
	$gamesplayed = $row['gamesplayed'];

}

?>
<header>
<img id="dp" src="dp.jpg">
<h2 id="title"><?php echo($name); ?></h2>
</header>
<article>
<aside>
<script type="text/javascript">
var edit = function()
{
	$("#bio > p").toggle();
	$("#bioedit").toggle();
	$("#details").toggle();
	$("#detailsedit").toggle();
}
</script>
<center>
<h3>b i o</h3>
<?php 
// if user has a special notification tied to their profile write the message
if ($special) { echo "<h3 class='special'>".$special."</h3>"; } 
?>
	<div id="bio">
	<p><?php echo $bio;?></p>
	<form action="update.php" method="post" id="updateform">
	<textarea id="bioedit" name="bioin" form="updateform" value="<?php echo $bio;?>"></textarea>
	</div>
	<table id="details">
	<?php
	// fill details table
	echo "<tr><td>Name</td><td><h4>". $name. "</h4></td></tr>";
	echo "<tr><td>Email</td><td><h4>". $email. "</h4></td></tr>";
	if ($age != null)
	{
		echo "<tr><td>Age</td><td><h4>". $age. "</h4></td></tr>";
	}
	if ($city != null)
	{
		echo "<tr><td>City</td><td><h4>". $city. "</h4></td></tr>";
	}
	if ($gender != null)
	{
		echo "<tr><td>Gender</td><td><h4>". $gender. "</h4></td></tr>";
	}
	echo "<tr><td>Highscore</td><td><h4>". $highscore. "</h4></td></tr>";
	echo "<tr><td>Games Played</td><td><h4>". $gamesplayed. "</h4></td></tr>";	
	?>
	</table>
	<table id="detailsedit">
		<tr><td>Name</td><td><input name="namein" type="text" value="<?php echo $name;?>"></td></tr>
		<tr><td>Email</td><td><input name="emailin" type="text" value="<?php echo $email;?>"></td></tr>
		<tr><td>Age</td><td><input name="agein" type="text" value="<?php echo $age;?>"></td></tr>
		<tr><td>City</td><td><input name="cityin" type="text" value="<?php echo $city;?>"></td></tr>
		<tr><td>Gender</td><td><input name="genderin" type="text" value="<?php echo $gender;?>"></td></tr>
	<tr><td></td><td><input type="submit" value="Submit"></td></tr>
	</form></table>
	<button class="edit" onclick="edit()">edit</button>
</center>
</aside>
<section>
<?php 
include("addsoap.php");
$query = "SELECT * FROM soap WHERE author_id = '".$id."';";
$results = mysqli_query($conn, $query);
if (mysqli_num_rows($results) > 0)
{
	while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
	{
		echo "<div class='soap'><h3>".$row['title']."</h3><h4>".$row['author']."</h4>
		<p>".$row['soaptext']."</p>".$row['soap_id']."</div>";
	}
}
// close mysql connection
mysqli_close($conn);
?>
</section>
</article>
</html>