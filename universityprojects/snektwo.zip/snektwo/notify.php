<?php
include("consql.php");
// query to fetch user with greatest highscore
$query = "SELECT user_id, highscore FROM users ORDER BY highscore DESC LIMIT 1";

// if specified male
if ($_POST['gender'] == "male")
{
	// special notification variable for top male player
	$special = "TOP LAD";
	// modified query to fetch male user with greatest highscore
	$query = "SELECT user_id, highscore FROM users WHERE gender = 'M' ORDER BY highscore DESC LIMIT 1";
}
if ($_POST['gender'] == "female")
{
	// special notification variable for top female player
	$special = "TOP LASS";
	// modified query to fetch female user with greatest highscore
	$query = "SELECT user_id, highscore FROM users WHERE gender = 'F' ORDER BY highscore DESC LIMIT 1";
}
// execute query
$results = mysqli_query($conn, $query);

if (mysqli_num_rows($results) > 0)
{
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC);
	// add special notification to user's account
	// special text is writen in users bio section
	mysqli_query($conn, "UPDATE users SET special = '".$special."' WHERE user_id = ".$row['user_id'].";" );
}
// close mysql connection
mysqli_close($conn);
// redirect back to stats page
header("location: stats.php");
exit;