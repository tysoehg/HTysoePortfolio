<?php
include("consql.php");
// script to update user details
// fetch new user detail variables from post form
// fields are prepopulated with original values to avoid overwriting with null or zero values
$name = $_POST['namein'];
$email = $_POST['emailin'];
$age = $_POST['agein'];
$city = $_POST['cityin'];
$gender = $_POST['genderin'];
$bio = $_POST['bioin'];

// query to update user details
$query = "update users set 
	name='".$name."', 
	email='".$email."',
	age='".$age."',
	city='".$city."',
	gender='".$gender."',
	bio ='".$bio."' where email = '".$email."';";
// execute query
if(mysqli_query($conn, $query))
{
	echo "success";
} else {
	echo mysqli_error($conn);
}
// close mysql connection
mysqli_close($conn);
// redirect back to profile page
header("location: profile.php");
exit;
?>