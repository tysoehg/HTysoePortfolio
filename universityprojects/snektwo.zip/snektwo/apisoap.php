<?php
include("consql.php");
// fetch POSTed values
$email = $_POST['email'];
$pass = $_POST['pass'];
$title = $_POST['title'];
$text = $_POST['soaptext'];
// using email from post form fetch details required to post a soap
$results = mysqli_query($conn, "SELECT name, pass, user_id FROM users WHERE email = '".$email."';");
$row = mysqli_fetch_array($results, MYSQLI_ASSOC);
// store values from database
$name = $row['name'];
$id = $row['user_id'];
// if password from post form matches that which resides in the database
if ($pass == $row['pass'])
{
	// query to create a new 'soap'
	$query = "insert into soap (title, author, author_id, soaptext) values ('".$title."','".$name."','".$id."','".$text."');";
	// execute mysql query
	if(mysqli_query($conn, $query))
	{
		// http response header
		header("Content-Type: application/json", NULL, 201);
	} 
	else 
	{
		// in case of error output error stats from mysql
		echo mysqli_error($conn);
	}
}
mysqli_close($conn);
?>