<?php
session_start();
include("nav.php");
include("consql.php");
?>
<header><h2 id="title">U S E R . I N D E X</h2></header>
<article>
<table id="allusers">
<?php
// fetch id and name from database
$results = mysqli_query($conn, "select user_id, name from users");
// if more than zero rows
if (mysqli_num_rows($results) > 0)
{
	// for each row
	while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
	{
		// output table row of values
		echo "<tr><td><a href='profile.php?id=".$row['user_id']."'>".$row['name']."</a></td></tr>";
	}
}
mysqli_close($conn);
?>
</table>
</article>