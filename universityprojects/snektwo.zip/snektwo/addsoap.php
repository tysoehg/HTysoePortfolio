<div class="soap">
	<center>
	<form id="newsoap" action="newsoap.php" method="post">
	<input type="text" value="TITLE" name="soaptitle">
	<br>
	<input type="text" name="soapauthor" value="<?php echo $_SESSION['name'];?>">
	<br><textarea id="soaptext" name="soaptext" form="newsoap"></textarea>
	<input id="soapsubmit" type="submit" value="Submit">
	</form>
	</center>
</div>