<?php
include("nav.php");
include("consql.php");
// sign in page
?>
<header>
<h2 id="title">L O G . I N</h2>
</header>
<article>
<aside>
<h3>Log In</h3>
<table>
<form method="POST" action="login.php">
<tr><td>email</td><td><input type="email" name="emaillogin"></td></tr>
<tr><td>password</td><td><input type="password" name="passlogin"></td></tr>
<tr><td></td><td><input type="submit" value="Submit"></td></tr>
</form>
</table>
</aside>
<section id="signup">
<h3>Sign Up</h3>
<table>
<form method="POST" action="signup.php">
<tr><td>email</td><td><input type="email" name="emailin"></td></tr>
<tr><td>password</td><td><input type="password" name="passin"></td></tr>
<tr><td>name</td><td><input type="text" name="namein"></td></tr>
<tr><td></td><td><input type="submit" value="Submit"></td></tr>
</form>
</table>
</section>
</article>