CREATE DATABASE  IF NOT EXISTS `snake` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `snake`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: snake
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `soap`
--

DROP TABLE IF EXISTS `soap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `soap` (
  `soap_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `author` varchar(50) NOT NULL,
  `soaptext` varchar(140) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `author_id` varchar(5) DEFAULT NULL,
  `likes` int(8) DEFAULT NULL,
  PRIMARY KEY (`soap_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `soap`
--

LOCK TABLES `soap` WRITE;
/*!40000 ALTER TABLE `soap` DISABLE KEYS */;
INSERT INTO `soap` VALUES (5,'Alan Swift','kahl max wil retun','muh gommunisms','2',4),(6,'Sam Mangum','REEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE\r\nLEAVE ME ALONE','TAXES','7',14),(7,'Sam Mangum','fajdsklafs','TITLE','7',0),(8,'John Tams','ur bad at to game','haha','8',3),(10,'Amy Amson','','look at me','10',NULL),(11,'John Tams','posting via api','john','8',NULL);
/*!40000 ALTER TABLE `soap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(80) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `age` int(3) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `bio` varchar(140) DEFAULT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `highscore` int(5) DEFAULT NULL,
  `gamesplayed` int(5) DEFAULT NULL,
  `special` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Kyle Sean','kyle@sean.com','password',33,'Manchester','M','Hi, my name is Kyle. Have you seen me? I hope you have.\r\nSee you, Kyle.',NULL,8,33,NULL),(2,'Alan Swift','alan@swift.com','password',12,'Hull','M','commie',NULL,18,14,NULL),(4,'Lee Ben Baum','1@1.com','password',84,NULL,NULL,NULL,NULL,22,12,NULL),(5,'Dolph Hindgrund','2@2.com','password',45,NULL,NULL,NULL,NULL,144,111,NULL),(7,'SAM','sam@mangum.com','password',20,NULL,NULL,'I AM SAM',1,14,88,NULL),(8,'John Tams','john@tams.com','password',24,'Liverpool','M',NULL,NULL,80,4,'TOP LAD'),(9,'Dave Mo','dave@mo.com','password',40,NULL,'M',NULL,NULL,9,9,NULL),(10,'Amy Amson','amy@me.com','password',23,'Stockholm','F',NULL,NULL,2,99,NULL),(11,'Sam Somik','sam@sam.sam','password',18,NULL,'F','I ALSO SAM AM',NULL,148,217,'TOP LASS');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-05 22:53:32
