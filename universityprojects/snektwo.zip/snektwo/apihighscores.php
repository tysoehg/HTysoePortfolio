<?php
include("consql.php");
$query = "SELECT name, highscore FROM users;";
// array to store all name highscore value pairs
$allRows = array();
// fetch name and highscore from database
$results = mysqli_query($conn, $query);
// if more than 0 rows
if (mysqli_num_rows($results) > 0)
{
	// for each row
	while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
	{
		// add row to final allRows array
		$allRows[] = $row;
	}
}
// close mysql connection
mysqli_close($conn);
// send success header
header("Content-Type: application/json", NULL, 200);
// send json encoded all rows array
echo json_encode($allRows);
?>