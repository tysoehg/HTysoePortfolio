<?php
session_start();
include("nav.php");
include("consql.php");
?>
<header>
<h2 id="title">S O A P . B O X</h2>
</header>
<article>
<section>
<?php 
include("addsoap.php");
// query to fetch every soap 
$query = "SELECT * FROM soap";
// execute query
$results = mysqli_query($conn, $query);
if (mysqli_num_rows($results) > 0)
{
	while($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
	{
		// display soap
		echo "<div class='soap'>";
		// if logged into admin account
		if ($_SESSION['admin'] == true)
		{
			// display delete button
			echo "<form method='POST' action='deletesoap.php'><button id='deletesoap' name='soap_id' value='".$row['soap_id']."' >delete</button></form>";
		}
		// display soap body
		echo "<h3>".$row['title']."</h3><a href='profile.php?id=".$row['author_id']."'><h4>".$row['author']."</h4></a>
	<p>".$row['soaptext']."</p>".$row['soap_id'].".<form action='like.php' method='post'><input type='hidden' name='sid' value='".$row['soap_id']."'><input type='submit' value='".$row['likes']." Likes'></form></div>";
	}
}
// close mysql connection
mysqli_close($conn);
?>
</section>
</article>