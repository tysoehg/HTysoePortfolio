<?php
include("consql.php");
// fetch signup variables from post form
$email = $_POST['emailin'];
$pass = $_POST['passin'];
$name = $_POST['namein'];
// query to create new user entry
$query = "insert into users (email, pass, name) values ('".$email."','".$pass."','".$name."');";
// only if each required field is not null
if($email != null && $pass != null && $name != null)
{
	// if succesful query
	if (mysqli_query($conn, $query))
	{
		// fetch from database now to ensure everything is good and did work
		$query = "select email, pass, user_id, name from users where email='".$email."';";
		$results = mysqli_query($conn, $query);
		if (mysqli_num_rows($results) > 0)
		{
			$row = mysqli_fetch_array($results, MYSQLI_ASSOC);
			// start session
			session_start();
			// set session variables user_id and name
			$_SESSION['user_id'] = $row['user_id'];
			$_SESSION['name'] = $row['name'];
			// redirect to profile
			header("location: profile.php");
			exit;
		}
	}
	else 
	{
		echo mysqli_error($conn);	
	}
}
// close mysql connection
mysqli_close($conn);
// if something has failed - other than the insert query (which outputs a mysql error) - redirect back to login/signup page
header("location: index.php");
exit;
?>