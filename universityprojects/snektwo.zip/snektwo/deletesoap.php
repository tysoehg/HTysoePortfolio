<?php
include("consql.php");
// script to delete a soap
// fetch id of soap to be deleted
$id = $_POST['soap_id'];
// query to delete said soap
$query = "delete from soap where soap_id = '" . $id . "';";
// execute said query to delete said soap
if (mysqli_query($conn, $query))
{
	echo "success";
}
else 
{
	// in case of error return mysqli error information
	echo mysqli_error($conn);
}
// close mysql connection
mysqli_close($conn);
// redirect back to the soapbox
header("location: soapbox.php");
exit;
?>