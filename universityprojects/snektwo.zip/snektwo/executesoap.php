<?php

// D E P R E C A T E D
// E                 E
// P                 P
// R                 R
// E                 E
// C                 C
// A                 A
// T                 T
// E                 E
// D E P R E C A T E D

// display soap with message "USER WAS BANNED FOR THIS POST"
include("consql.php");
$id = $_POST['soap_id'];
$query = "update soap set executed = true where soap_id = '" . $id . "';";
if (mysqli_query($conn, $query))
{
	echo "success";
}
else 
{
	echo mysqli_error($conn);
}
header("location: soapbox.php");
exit;
?>